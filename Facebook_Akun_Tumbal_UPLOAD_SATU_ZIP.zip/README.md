# Facebook Akun Tumbal — HTML WebView APK starter

This packages the supplied HTML preview into a basic Android WebView app and includes a GitHub Actions workflow to build a debug APK.

## Build using GitHub Actions
1. Create a new GitHub repository named `Facebook-Akun-Tumbal`.
2. Extract this ZIP.
3. Upload the extracted **project contents** to the repository root (not the enclosing folder). Include `.github/workflows/build-apk.yml`.
4. Open repository → Actions → `Build Facebook Akun Tumbal APK` → `Run workflow` (or wait for push build).
5. When the run finishes, open it → Artifacts → download `Facebook-Akun-Tumbal-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Notes
This is a WebView wrapper around the HTML preview. The HTML prototype keeps account data temporarily in page memory; it is not secure persistent storage. TOTP needs WebCrypto support. This is a debug APK, not a release-signed production app. Do not commit real credentials or secrets.
